function renderPecas(pecas) {
    const grid = document.querySelector(".card-grid");
    grid.innerHTML = "";
    pecas.forEach(peca => {
        const card = document.createElement("div");
        card.className = "card";
        card.innerHTML = `
            <img src="${peca.foto}" alt="foto da peça">
            <div class="quantity-box">
                <p>Qtd: ${peca.quantidade}</p>
            </div>
            <p class="nome">${peca.nome}</p>
            <p class="desc">${peca.descricao}</p>
            <button class="add">Adicionar +</button>
        `;
        grid.appendChild(card);
    });
}

addEventListener("DOMContentLoaded", () => {
    listarPecas().then(res => {
        if (res.status === 200) renderPecas(res.data);
        else alert("Erro ao listar peças");
    });
});