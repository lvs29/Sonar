function v(id) {
    return document.getElementById(id).value;
}

async function req(method, url, body = null, isForm = false) {
    const opts = { method, headers: {} };
    if (TOKEN) opts.headers["Authorization"] = `Bearer ${TOKEN}`;
    if (body) {
    if (isForm) {
        opts.body = body;
    } else {
        opts.headers["Content-Type"] = "application/json";
        opts.body = JSON.stringify(body);
    }
    }
    const res = await fetch(url, opts);
    const json = await res.json();
    return { status: res.status, data: json };
}

// ─── Auth ──────────────────────────────────────────────────────────────────

async function restaurarSessao() {
    if (!TOKEN) return;

    const { status, data } = await req("GET", "/api/auth/me");

    if (status === 200) {
        document.getElementById("usuario-display").textContent = data.nome;
        document.getElementById("role-display").textContent = data.role;
    } else {
        // Token inválido ou expirado
        TOKEN = null;
        localStorage.removeItem("token");
    }
}

async function fazerLogin() {
    const username = v("login-username");
    const senha = v("login-senha");
    if (!username || !senha) return alert("Preencha username e senha");
    const { status, data } = await req("POST", "/api/auth/login", { username, senha });
    if (status === 200) {
    TOKEN = data.token;
    localStorage.setItem("token", TOKEN);
    document.getElementById("usuario-display").textContent = data.usuario.nome;
    document.getElementById("role-display").textContent = data.usuario.role;
    window.location.href = "/";
    } else {
        window.alert('erro')
    }
}

async function fazerLogout() {
    await req("POST", "/api/auth/logout");
    TOKEN = null;
    localStorage.removeItem("token");
    document.getElementById("token-display").textContent = "(nenhum)";
    document.getElementById("usuario-display").textContent = "(não logado)";
    document.getElementById("role-display").textContent = "—";
}

// ─── Usuários ──────────────────────────────────────────────────────────────

function criarUsuario() {
    const nome = v("criar-u-nome").trim();
    const username = v("criar-u-username").trim();
    const senha = v("criar-u-senha");
    if (!nome || !username || !senha) return alert("nome, username e senha são obrigatórios");
    req("POST", "/api/usuarios", { nome, username, senha, role: v("criar-u-role") });
}

function atualizarUsuario() {
    const id = v("upd-uid");
    if (!id) return alert("Informe o ID");
    const body = {};
    if (v("upd-u-nome").trim()) body.nome = v("upd-u-nome").trim();
    if (v("upd-u-username").trim()) body.username = v("upd-u-username").trim();
    if (v("upd-u-senha")) body.senha = v("upd-u-senha");
    if (v("upd-u-role")) body.role = v("upd-u-role");
    req("PUT", `/api/usuarios/${id}`, body);
}

function deletarUsuario() {
    const id = v("del-uid");
    if (!id) return alert("Informe o ID");
    if (!confirm(`Deletar usuário ${id}?`)) return;
    req("DELETE", `/api/usuarios/${id}`);
}

// ─── Peças ─────────────────────────────────────────────────────────────────

function listarPecas() {
    return req("GET", "/api/pecas");
}

function checarDisponibilidade() {
    const id = v("disp-peca-id");
    const data = v("disp-data");
    if (!id || !data) return alert("ID e data são obrigatórios");
    req("GET", `/api/pecas/${id}/disponibilidade?data=${data}`);
}

function criarPeca() {
    const nome = v("criar-peca-nome").trim();
    if (!nome) return alert("Nome é obrigatório");
    const foto = document.getElementById("criar-peca-foto").files[0];
    const form = new FormData();
    form.append("nome", nome);
    form.append("descricao", v("criar-peca-descricao"));
    form.append("quantidade", v("criar-peca-quantidade") || 0);
    if (foto) form.append("foto", foto);
    req("POST", "/api/pecas", form, true);
}

function atualizarPeca() {
    const id = v("upd-peca-id");
    if (!id) return alert("Informe o ID");
    const body = {};
    if (v("upd-peca-nome").trim()) body.nome = v("upd-peca-nome").trim();
    if (v("upd-peca-descricao").trim()) body.descricao = v("upd-peca-descricao").trim();
    if (v("upd-peca-quantidade") !== "") body.quantidade = parseInt(v("upd-peca-quantidade"));
    req("PUT", `/api/pecas/${id}`, body);
}

function ajustarQuantidade() {
    const id = v("delta-peca-id");
    const delta = v("delta-valor");
    if (!id || delta === "") return alert("ID e delta são obrigatórios");
    req("PATCH", `/api/pecas/${id}/quantidade`, { delta: parseInt(delta) });
}

function deletarPeca() {
    const id = v("del-peca-id");
    if (!id) return alert("Informe o ID");
    if (!confirm(`Deletar peça ${id}?`)) return;
    req("DELETE", `/api/pecas/${id}`);
}

// ─── Reservas ──────────────────────────────────────────────────────────────

function listarReservas() {
    const params = new URLSearchParams();
    if (v("lista-res-peca-id")) params.append("peca_id", v("lista-res-peca-id"));
    if (document.getElementById("lista-res-ativas").checked) params.append("ativas", "true");
    req("GET", `/api/reservas?${params}`);
}

function criarReserva() {
    const peca_id = v("criar-res-peca-id");
    const data_retirada = v("criar-res-retirada");
    const data_devolucao = v("criar-res-devolucao");
    if (!peca_id || !data_retirada || !data_devolucao) return alert("peca_id, data_retirada e data_devolucao são obrigatórios");
    const body = { peca_id: parseInt(peca_id), data_retirada, data_devolucao, quantidade: parseInt(v("criar-res-qtd") || 1) };
    if (v("criar-res-obs").trim()) body.observacoes = v("criar-res-obs").trim();
    req("POST", "/api/reservas", body);
}

function atualizarReserva() {
    const id = v("upd-res-id");
    if (!id) return alert("Informe o ID");
    const body = {};
    if (v("upd-res-retirada")) body.data_retirada = v("upd-res-retirada");
    if (v("upd-res-devolucao")) body.data_devolucao = v("upd-res-devolucao");
    if (v("upd-res-qtd")) body.quantidade = parseInt(v("upd-res-qtd"));
    if (v("upd-res-obs").trim()) body.observacoes = v("upd-res-obs").trim();
    req("PUT", `/api/reservas/${id}`, body);
}

function deletarReserva() {
    const id = v("del-res-id");
    if (!id) return alert("Informe o ID");
    if (!confirm(`Deletar reserva ${id}?`)) return;
    req("DELETE", `/api/reservas/${id}`);
}