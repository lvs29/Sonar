import sqlite3
import os
import hashlib
import secrets

DB_PATH = os.environ.get("DB_PATH", "estoque.db")


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    conn = get_db()
    with conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS usuarios (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                nome        TEXT    NOT NULL,
                username    TEXT    NOT NULL UNIQUE,
                senha_hash  TEXT    NOT NULL,
                role        TEXT    NOT NULL DEFAULT 'user',
                criado_em   TEXT    NOT NULL DEFAULT (datetime('now'))
            );

            CREATE TABLE IF NOT EXISTS sessoes (
                token       TEXT    PRIMARY KEY,
                usuario_id  INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
                criado_em   TEXT    NOT NULL DEFAULT (datetime('now'))
            );

            CREATE TABLE IF NOT EXISTS pecas (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                nome        TEXT    NOT NULL,
                descricao   TEXT,
                quantidade  INTEGER NOT NULL DEFAULT 0,
                foto_path   TEXT,
                criado_em   TEXT    NOT NULL DEFAULT (datetime('now'))
            );

            CREATE TABLE IF NOT EXISTS reservas (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                peca_id         INTEGER NOT NULL REFERENCES pecas(id) ON DELETE CASCADE,
                usuario_id      INTEGER REFERENCES usuarios(id) ON DELETE SET NULL,
                solicitante     TEXT    NOT NULL,
                data_retirada   TEXT    NOT NULL,
                data_devolucao  TEXT,
                quantidade      INTEGER NOT NULL DEFAULT 1,
                devolvido       INTEGER NOT NULL DEFAULT 0,
                retirado        INTEGER NOT NULL DEFAULT 0,
                observacoes     TEXT,
                criado_em       TEXT    NOT NULL DEFAULT (datetime('now'))
            );

            CREATE INDEX IF NOT EXISTS idx_reservas_peca      ON reservas(peca_id);
            CREATE INDEX IF NOT EXISTS idx_reservas_devolvido  ON reservas(devolvido);
            CREATE INDEX IF NOT EXISTS idx_reservas_retirada   ON reservas(data_retirada);
            CREATE INDEX IF NOT EXISTS idx_sessoes_usuario     ON sessoes(usuario_id);
        """)
    conn.close()
    _garantir_admin()


def _hash(senha: str) -> str:
    return hashlib.sha256(senha.encode()).hexdigest()


def _garantir_admin():
    """Cria o admin padrão se não existir nenhum usuário admin."""
    conn = get_db()
    existe = conn.execute("SELECT 1 FROM usuarios WHERE role = 'admin' LIMIT 1").fetchone()
    conn.close()
    if not existe:
        criar_usuario("Admin", "admin", os.environ.get("ADMIN_SENHA", "admin123"), role="admin")
        print("[db] Admin criado — usuario: admin | senha: admin123")


# ─── Usuários ─────────────────────────────────────────────────────────────────

def listar_usuarios():
    conn = get_db()
    rows = conn.execute(
        "SELECT id, nome, username, role, criado_em FROM usuarios ORDER BY nome"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def buscar_usuario(usuario_id: int):
    conn = get_db()
    row = conn.execute(
        "SELECT id, nome, username, role, criado_em FROM usuarios WHERE id = ?",
        (usuario_id,),
    ).fetchone()
    conn.close()
    return dict(row) if row else None


def buscar_usuario_por_username(username: str):
    conn = get_db()
    row = conn.execute("SELECT * FROM usuarios WHERE username = ?", (username,)).fetchone()
    conn.close()
    return dict(row) if row else None


def criar_usuario(nome: str, username: str, senha: str, role: str = "user"):
    conn = get_db()
    with conn:
        cur = conn.execute(
            "INSERT INTO usuarios (nome, username, senha_hash, role) VALUES (?, ?, ?, ?)",
            (nome, username, _hash(senha), role),
        )
    conn.close()
    return buscar_usuario(cur.lastrowid)


def atualizar_usuario(usuario_id: int, **campos):
    permitidos = {"nome", "username", "role"}
    updates = {k: v for k, v in campos.items() if k in permitidos}
    if "senha" in campos:
        updates["senha_hash"] = _hash(campos["senha"])
    if not updates:
        return buscar_usuario(usuario_id)
    set_clause = ", ".join(f"{k} = ?" for k in updates)
    valores = list(updates.values()) + [usuario_id]
    conn = get_db()
    with conn:
        conn.execute(f"UPDATE usuarios SET {set_clause} WHERE id = ?", valores)
    conn.close()
    return buscar_usuario(usuario_id)


def deletar_usuario(usuario_id: int):
    conn = get_db()
    with conn:
        conn.execute("DELETE FROM usuarios WHERE id = ?", (usuario_id,))
    conn.close()


# ─── Sessões ──────────────────────────────────────────────────────────────────

def criar_sessao(usuario_id: int) -> str:
    token = secrets.token_hex(32)
    conn = get_db()
    with conn:
        conn.execute(
            "INSERT INTO sessoes (token, usuario_id) VALUES (?, ?)",
            (token, usuario_id),
        )
    conn.close()
    return token


def buscar_sessao(token: str):
    conn = get_db()
    row = conn.execute(
        """
        SELECT u.id, u.nome, u.username, u.role
        FROM sessoes s
        JOIN usuarios u ON u.id = s.usuario_id
        WHERE s.token = ?
        """,
        (token,),
    ).fetchone()
    conn.close()
    return dict(row) if row else None


def deletar_sessao(token: str):
    conn = get_db()
    with conn:
        conn.execute("DELETE FROM sessoes WHERE token = ?", (token,))
    conn.close()


def login(username: str, senha: str):
    """Retorna (usuario_dict, token) ou (None, None)."""
    usuario = buscar_usuario_por_username(username)
    if not usuario or usuario["senha_hash"] != _hash(senha):
        return None, None
    token = criar_sessao(usuario["id"])
    usuario.pop("senha_hash", None)
    return usuario, token


# ─── Peças ────────────────────────────────────────────────────────────────────

def listar_pecas():
    conn = get_db()
    rows = conn.execute("SELECT * FROM pecas ORDER BY nome").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def buscar_peca(peca_id: int):
    conn = get_db()
    row = conn.execute("SELECT * FROM pecas WHERE id = ?", (peca_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def criar_peca(nome: str, descricao: str = None, quantidade: int = 0, foto_path: str = None):
    conn = get_db()
    with conn:
        cur = conn.execute(
            "INSERT INTO pecas (nome, descricao, quantidade, foto_path) VALUES (?, ?, ?, ?)",
            (nome, descricao, quantidade, foto_path),
        )
    conn.close()
    return buscar_peca(cur.lastrowid)


def atualizar_peca(peca_id: int, **campos):
    permitidos = {"nome", "descricao", "quantidade", "foto_path"}
    updates = {k: v for k, v in campos.items() if k in permitidos}
    if not updates:
        return buscar_peca(peca_id)
    set_clause = ", ".join(f"{k} = ?" for k in updates)
    valores = list(updates.values()) + [peca_id]
    conn = get_db()
    with conn:
        conn.execute(f"UPDATE pecas SET {set_clause} WHERE id = ?", valores)
    conn.close()
    return buscar_peca(peca_id)


def deletar_peca(peca_id: int):
    conn = get_db()
    with conn:
        conn.execute("DELETE FROM pecas WHERE id = ?", (peca_id,))
    conn.close()


def ajustar_quantidade(peca_id: int, delta: int):
    conn = get_db()
    with conn:
        conn.execute(
            "UPDATE pecas SET quantidade = MAX(0, quantidade + ?) WHERE id = ?",
            (delta, peca_id),
        )
    conn.close()
    return buscar_peca(peca_id)


def disponibilidade_peca(peca_id: int, data: str) -> int:
    """
    Retorna quantas unidades estão disponíveis em uma data específica.
    Desconta reservas não devolvidas que estejam ativas nessa data:
      data_retirada <= data AND (data_devolucao IS NULL OR data_devolucao >= data)
    """
    peca = buscar_peca(peca_id)
    if not peca:
        return 0
    conn = get_db()
    row = conn.execute(
        """
        SELECT COALESCE(SUM(quantidade), 0) AS reservado
        FROM reservas
        WHERE peca_id = ?
          AND devolvido = 0
          AND data_retirada <= ?
          AND (data_devolucao IS NULL OR data_devolucao >= ?)
        """,
        (peca_id, data, data),
    ).fetchone()
    conn.close()
    return max(0, peca["quantidade"] - row["reservado"])


# ─── Reservas ─────────────────────────────────────────────────────────────────

def listar_reservas(peca_id: int = None, apenas_ativas: bool = False, usuario_id: int = None):
    conn = get_db()
    query = """
        SELECT r.*, p.nome AS peca_nome, u.nome AS usuario_nome
        FROM reservas r
        JOIN pecas p ON p.id = r.peca_id
        LEFT JOIN usuarios u ON u.id = r.usuario_id
        WHERE 1=1
    """
    params = []
    if peca_id is not None:
        query += " AND r.peca_id = ?"
        params.append(peca_id)
    if apenas_ativas:
        query += " AND r.devolvido = 0"
    if usuario_id is not None:
        query += " AND r.usuario_id = ?"
        params.append(usuario_id)
    query += " ORDER BY r.data_retirada DESC"
    rows = conn.execute(query, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def buscar_reserva(reserva_id: int):
    conn = get_db()
    row = conn.execute(
        """
        SELECT r.*, p.nome AS peca_nome, u.nome AS usuario_nome
        FROM reservas r
        JOIN pecas p ON p.id = r.peca_id
        LEFT JOIN usuarios u ON u.id = r.usuario_id
        WHERE r.id = ?
        """,
        (reserva_id,),
    ).fetchone()
    conn.close()
    return dict(row) if row else None


def criar_reserva(
    peca_id: int,
    solicitante: str,
    data_retirada: str,
    data_devolucao: str,
    quantidade: int = 1,
    observacoes: str = None,
    usuario_id: int = None,
):
    conn = get_db()
    with conn:
        cur = conn.execute(
            """
            INSERT INTO reservas
                (peca_id, usuario_id, solicitante, data_retirada, data_devolucao, quantidade, observacoes)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (peca_id, usuario_id, solicitante, data_retirada, data_devolucao, quantidade, observacoes),
        )
    conn.close()
    return buscar_reserva(cur.lastrowid)


def reserva_atrasada(reserva: dict) -> bool:
    from datetime import date
    if reserva["devolvido"] or not reserva["data_devolucao"]:
        return False
    return date.fromisoformat(reserva["data_devolucao"]) < date.today()

def marcar_entrege(reserva_id: int):
    conn = get_db()
    with conn:
        conn.execute(
            "UPDATE reservas SET retirado = 1 WHERE id = ?",
            (reserva_id,),
        )
    conn.close()
    return buscar_reserva(reserva_id)


def marcar_devolvido(reserva_id: int):
    conn = get_db()
    with conn:
        conn.execute(
            "UPDATE reservas SET devolvido = 1, data_devolucao = date('now') WHERE id = ?",
            (reserva_id,),
        )
    conn.close()
    return buscar_reserva(reserva_id)


def atualizar_reserva(reserva_id: int, **campos):
    permitidos = {"solicitante", "data_retirada", "data_devolucao", "devolvido", "quantidade", "observacoes"}
    updates = {k: v for k, v in campos.items() if k in permitidos}
    if not updates:
        return buscar_reserva(reserva_id)
    set_clause = ", ".join(f"{k} = ?" for k in updates)
    valores = list(updates.values()) + [reserva_id]
    conn = get_db()
    with conn:
        conn.execute(f"UPDATE reservas SET {set_clause} WHERE id = ?", valores)
    conn.close()
    return buscar_reserva(reserva_id)


def deletar_reserva(reserva_id: int):
    conn = get_db()
    with conn:
        conn.execute("DELETE FROM reservas WHERE id = ?", (reserva_id,))
    conn.close()


if __name__ == "__main__":
    init_db()
    print("Database inicializada em", DB_PATH)